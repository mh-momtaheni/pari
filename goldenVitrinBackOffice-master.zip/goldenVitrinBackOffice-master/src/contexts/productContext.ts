import { createContext } from 'react'

import type { Image, ProductVariant } from '@/types/productDetail.type'

interface ProductContexType {
  imageCover: Image
  vendorId: number
  productVariants: ProductVariant[]
  handleOpenRejectionModal?: () => void
}

const initialValue = {
  imageCover: { id: 0, accessibilityCaption: '', url: '' },
  vendorId: 0,
  productVariants: [
    {
      id: 0,
      isAvailable: false,
      isPublished: false,
      productVariantName: '',
      productVariantPrice: 0,
      sku: '',
      variantId: [0],
      variantTitle: ['']
    }
  ]
}

export const ProductContex = createContext<ProductContexType>(initialValue)
