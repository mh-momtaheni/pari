import type { ReactElement } from 'react'
import React from 'react'

import Dialog from '@mui/material/Dialog'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import DialogActions from '@mui/material/DialogActions'
import { Button, TextField, Typography } from '@mui/material'
import type { SubmitHandler } from 'react-hook-form'
import { useForm } from 'react-hook-form'

import { useDeactiveProduct } from '@/apis/dash/v2/product/productDeactive'

type RejectionInput = {
  rejectionField: string
}

interface Props {
  open: boolean
  onClose: () => void
  id: number
}

export default function ProductRejectionModal({ open, onClose, id }: Props): ReactElement {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm<RejectionInput>()

  const { mutate: deactiveProduct, isPending } = useDeactiveProduct({ id })

  const onSubmit: SubmitHandler<RejectionInput> = value => {
    deactiveProduct({ comment: value.rejectionField })

    reset()

    onClose()
  }

  return (
    <Dialog open={open} onClose={onClose} fullWidth>
      <DialogTitle>رد محصول</DialogTitle>

      <DialogContent className='flex flex-col items-center justify-center px-12'>
        <form onSubmit={handleSubmit(onSubmit)} className='w-full'>
          <div className='flex flex-col gap-y-2 h-14'>
            <TextField
              fullWidth
              dir='rtl'
              placeholder=' دلیل رد محصول را بنویسید '
              defaultValue=''
              {...register('rejectionField', { required: true })}
            />

            {errors.rejectionField && (
              <Typography className='text-red-500 text-sm'>لطفا دلیل رد محصول را بنویسید</Typography>
            )}
          </div>

          <DialogActions className='mt-4 justify-self-end pl-0 ml-[-16px] w-full'>
            <Button className='w-48' variant='contained' color='error' type='submit' disabled={isPending}>
              ارسال پیام به کاربر
            </Button>

            <Button className='w-24' variant='outlined' color='secondary' onClick={onClose}>
              انصراف
            </Button>
          </DialogActions>
        </form>
      </DialogContent>
    </Dialog>
  )
}
