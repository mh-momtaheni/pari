import React, { useContext, type ReactElement } from 'react'

import { Button } from '@mui/material'

import { ProductContex } from '@/contexts/productContext'

interface Props {
  onActive: () => void
}

export default function CTAButtons({ onActive }: Props): ReactElement {
  const { handleOpenRejectionModal } = useContext(ProductContex)

  return (
    <div className='flex gap-x-2'>
      <Button className='w-40' variant='contained' color='primary' onClick={onActive}>
        تایید محتوا
      </Button>

      <Button className='w-40' variant='outlined' color='error' onClick={handleOpenRejectionModal}>
        رد محتوا
      </Button>
    </div>
  )
}
