import React, { useContext, type ReactElement } from 'react'

import ProductGeneralInfo from './ProductGeneralInfo'
import ProductCard from '@/components/product-card/ProductCard'
import CTAButtons from './CTAButtons'
import type { ProdcutStatusType } from '@/types/productStatus.type'
import type { ChipsColorTypes } from '@/components/chips/chips.component'
import StatusChips from '@/components/chips/chips.component'
import { productStatusChipsColorConstant, productStatusConstant } from '@/constants/productStatus.constant'
import { useActiveProduct } from '@/apis/dash/v2/product/productActive'
import { ProductContex } from '@/contexts/productContext'

interface productGeneralInfor {
  id: number
  productName: string
  productId: number
  category: string
  productSlug: string
  description: string
  productStatus: ProdcutStatusType
  vendorSlug: string
}

interface Props {
  productGeneralInfo: productGeneralInfor
  vendorName: string
}

const Header = ({ productGeneralInfo, vendorName }: Props): ReactElement => {
  const { vendorId } = useContext(ProductContex)

  const { mutate: activeProduct } = useActiveProduct({ id: productGeneralInfo.id })

  const handleActiveProduct = () => {
    activeProduct()
  }

  const data = [
    {
      label: 'نام محصول',
      info: productGeneralInfo.productName
    },

    {
      label: 'دسته بندی محصول',
      info: productGeneralInfo.category
    },

    {
      label: 'مشاهده فروشگاه در پنل',
      info: vendorName,
      link: true,
      href: `/vendors/list/${vendorId}`
    },

    {
      label: 'وضعیت محصول',
      info: (
        <StatusChips
          label={productStatusConstant[productGeneralInfo.productStatus]}
          color={productStatusChipsColorConstant[productGeneralInfo.productStatus] as ChipsColorTypes}
        />
      )
    },

    {
      label: 'اسلاگ محصول',
      info: productGeneralInfo.productSlug
    },

    {
      label: 'شناسه محصول',
      info: productGeneralInfo.productId
    },

    {
      label: 'مشاهده محصول در  سایت',
      info: vendorName,
      link: true,
      href: `https://witro.shop/${productGeneralInfo.vendorSlug}/${productGeneralInfo.productId}`
    }
  ]

  const description = {
    label: 'توضیحات محصول',
    info: productGeneralInfo.description
  }

  return (
    <header className='flex w-full '>
      <ProductCard title='اطلاعات محصول' buttons={<CTAButtons onActive={handleActiveProduct} />}>
        <ProductGeneralInfo productInformation={data} description={description} />
      </ProductCard>
    </header>
  )
}

export default Header
