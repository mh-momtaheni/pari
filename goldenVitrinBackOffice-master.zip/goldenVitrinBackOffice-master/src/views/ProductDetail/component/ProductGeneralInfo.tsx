import React, { type ReactNode, useContext, type ReactElement } from 'react'

import Image from 'next/image'

import Link from 'next/link'

import { Typography } from '@mui/material'

import { ProductContex } from '@/contexts/productContext'

interface Info {
  label: string
  info: string | number | ReactNode
  link?: boolean
  href?: string
}

interface Props {
  productInformation: Info[]
  description: Info
}

const ProductGeneralInfo = ({ productInformation, description }: Props): ReactElement => {
  const { imageCover } = useContext(ProductContex)

  return (
    <div className='w-full h-full'>
      <div className='flex  gap-x-5'>
        <div className='flex flex-col gap-y-3'>
          <Typography className='text-sm  font-light'>عکس اصلی محصول</Typography>

          <Image height={220} width={220} src={imageCover?.url} className='rounded' alt='Profile Background' />
        </div>

        <div className='flex flex-col gap-y-8 '>
          <div className='grid grid-cols-4  gap-y-12 gap-x-12  '>
            {productInformation?.map(item => (
              <div key={item.label} className='flex flex-col  justify-between gap-y-1 '>
                <Typography className='text-sm  font-light'>{item.label}</Typography>

                {item.link ? (
                  <Link className='text-blue-500' href={item.href || ''}>
                    {item.info}
                  </Link>
                ) : (
                  <div className='text-[16px] font-bold  '>{item.info}</div>
                )}
              </div>
            ))}
          </div>

          <div className='flex flex-col gap-y-2  justify-self-start self-start'>
            <Typography className='text-sm  font-light'>{description.label}</Typography>

            <Typography className='text-[16px]  '>{description.info}</Typography>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ProductGeneralInfo
