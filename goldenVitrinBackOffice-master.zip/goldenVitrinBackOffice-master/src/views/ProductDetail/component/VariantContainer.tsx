import React, { useContext, type ReactElement } from 'react'

import { Typography } from '@mui/material'

import numeral from 'numeral'

import classNames from 'classnames'

import StatusChips from '@/components/chips/chips.component'
import { ProductContex } from '@/contexts/productContext'

export default function VariantContainer(): ReactElement {
  const { productVariants } = useContext(ProductContex)

  return (
    <div className='grid grid-cols-3  gap-y-8  '>
      {productVariants.map(variant => (
        <div
          key={variant.id}
          className={classNames('flex flex-col justify-center items-center gap-y-3  px-4 border-l-2 ')}
        >
          <div className=' flex gap-x-4 '>
            {variant.variantTitle.map(title => (
              <StatusChips key={title} color='secondary' label={title} className='px-3' />
            ))}
          </div>

          {variant.variantTitle.length > 0 ? (
            <Typography className='text-sm'>
              {numeral(variant.productVariantPrice / 10).format('0,0')}
              <span className='pr-1 text-[10px]'>تومان</span>
            </Typography>
          ) : (
            <Typography className='text-sm'>این محصول ویژگی ندارد</Typography>
          )}
        </div>
      ))}
    </div>
  )
}
