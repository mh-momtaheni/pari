'use client'

import React, { useState, type ReactElement } from 'react'

import { useParams } from 'next/navigation'

import useGetProductDetailItem from '@/apis/dash/v2/product/productDetail'
import Header from './Header'
import Body from './Body'
import { ProductContex } from '@/contexts/productContext'
import type { ProdcutStatusType } from '@/types/productStatus.type'
import ProductRejectionModal from './ProductRjectionModal'

const Main = (): ReactElement => {
  const params = useParams()
  const id = Number(params.id)
  const [openRejectionModal, setOpenRejectionModal] = useState(false)

  const { data } = useGetProductDetailItem({ id })

  const imageCover = data?.productMedia.thumbnailImageProduct || { id: 0, accessibilityCaption: '', url: '' }
  const vendorId = data?.vendorId || 0
  const vendorName = data?.vendorName || ''

  const productGeneralInfo = {
    id,
    productStatus: (data?.productStatus as ProdcutStatusType) || '',
    productName: data?.name || '',
    productId: data?.id || 0,
    category: data?.categoryName || '',
    productSlug: data?.slug || '',
    description: data?.description || '',
    vendorSlug: data?.vendorSlug || ''
  }

  const productPriceInfo = {
    price: data?.price || 0,
    discount: data?.discount || 0,
    availability: data?.availability || '',
    isPublished: data?.published || true
  }

  const productDateInfo = {
    createdDate: data?.createdDateTime || '',
    modifiedDate: data?.modifiedDateTime || '',
    approvedDate: data?.approvedDateTime || ''
  }

  const productVariants = data?.variation?.productVariants || [
    {
      id: 0,
      isAvailable: false,
      isPublished: false,
      productVariantName: '',
      productVariantPrice: 0,
      sku: '',
      variantId: [0],
      variantTitle: ['']
    }
  ]

  const productImages = data?.productMedia?.productImagesProduct || [{ id: 0, accessibilityCaption: '', url: '' }]

  const handleRejectionModalToggle = () => {
    setOpenRejectionModal(open => !open)
  }

  return (
    <ProductContex.Provider
      value={{ imageCover, vendorId, productVariants, handleOpenRejectionModal: handleRejectionModalToggle }}
    >
      <div className='w-full h-full'>
        <Header productGeneralInfo={productGeneralInfo} vendorName={vendorName} />

        <Body productPriceInfo={productPriceInfo} productDateInfo={productDateInfo} productImages={productImages} />
      </div>

      <ProductRejectionModal open={openRejectionModal} onClose={handleRejectionModalToggle} id={id} />
    </ProductContex.Provider>
  )
}

export default Main
