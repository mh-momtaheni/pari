import React, { type ReactElement } from 'react'

import numeral from 'numeral'

import { Typography } from '@mui/material'

import ProductCard from '@/components/product-card/ProductCard'
import ListItems from '@/components/ListItem/ListItems'
import dateFormatter from '@/utils/date-formatter.util'
import VariantContainer from './VariantContainer'
import type { Image } from '@/types/productDetail.type'
import Gallery from '@/components/gallery/Gallery'
import StatusChips from '@/components/chips/chips.component'

interface ProductDateInfo {
  createdDate: string
  modifiedDate: string
  approvedDate: string
}
interface ProductPriceInfo {
  price: number
  discount: number
  availability: string
  isPublished: boolean
}

interface Props {
  productPriceInfo: ProductPriceInfo
  productDateInfo: ProductDateInfo
  productImages: Image[]
}

const Body = ({ productPriceInfo, productDateInfo, productImages }: Props): ReactElement => {
  const priceData = [
    {
      label: 'مبلغ :',
      info: numeral(productPriceInfo.price / 10).format('0,0') + ' تومان'
    },

    {
      label: 'تخفیف :',
      info: productPriceInfo.discount * 100 + ' %'
    },

    {
      label: 'موجودی :',
      info:
        productPriceInfo.availability === 'InStock' ? (
          <StatusChips className='w-20' label='موجود' color='success' />
        ) : (
          <StatusChips className='w-20' label='ناموحود' color='error' />
        )
    },

    {
      label: 'آرشیو :',
      info: <StatusChips className='w-20' label={productPriceInfo.isPublished ? 'خیر' : 'بله'} color='secondary' />
    }
  ]

  const dateData = [
    {
      label: 'ایجاد :',
      info: productDateInfo.createdDate.length > 0 ? dateFormatter(productDateInfo.createdDate) : '----'
    },

    {
      label: 'ویرایش :',
      info: productDateInfo.modifiedDate?.length > 0 ? dateFormatter(productDateInfo.modifiedDate) : '----'
    },

    {
      label: 'تایید :',
      info: productDateInfo.approvedDate?.length > 0 ? dateFormatter(productDateInfo.approvedDate) : '----'
    }
  ]

  const imagesData = productImages

  return (
    <main className='flex flex-col gap-y-6 '>
      <div className='mt-6 flex gap-x-4'>
        <ProductCard title=' مبلغ'>
          <ListItems items={priceData} />
        </ProductCard>

        <ProductCard title=' تاریخ'>
          <ListItems items={dateData} />
        </ProductCard>
      </div>

      <ProductCard title='ویژگی ها'>
        <VariantContainer />
      </ProductCard>

      <ProductCard title='عکس ها '>
        {imagesData.length ? (
          <Gallery imageHeight={350} imageWidth={350} images={imagesData} />
        ) : (
          <Typography>این محصول عکسی ندارد</Typography>
        )}
      </ProductCard>
    </main>
  )
}

export default Body
