import type { ReactElement } from 'react'
import React from 'react'

import Main from './component/Main'

const ProductDetail = (): ReactElement => {
  return <Main />
}

export default ProductDetail
