'use client'

import React, { type ChangeEvent, useState, type ReactElement } from 'react'

import Link from 'next/link'

import {
  createColumnHelper,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getPaginationRowModel,
  useReactTable
} from '@tanstack/react-table'

import { Card, CardHeader } from '@mui/material'

import numeral from 'numeral'

import styles from '@core/styles/table.module.css'

import type { OrderItem, OrderSortDirectionType, OrderStatusFilterType } from '@/apis/dash/v2/orders/orderList.api'
import useGetOrdersList from '@/apis/dash/v2/orders/orderList.api'
import dateFormatter from '@/utils/date-formatter.util'
import type { OrderStatusType } from '@/types/orderStatus.type'
import type { ChipsColorTypes } from '@/components/chips/chips.component'
import StatusChips from '@/components/chips/chips.component'
import { orderStatusChipsColorConstant, orderStatusConstant } from '@/constants/orderStatus.constant'
import Table from '@/components/table'
import OrdersFilter from './OrderFilter'

export default function Main(): ReactElement {
  const [page, setPage] = useState<number>(1)
  const [filterStatus, setFilterStatus] = useState<OrderStatusFilterType>()
  const [sortDirection, setSortDirection] = useState<OrderSortDirectionType>('Descending')
  const [vendorName, setvendorName] = useState<string>('')

  const { data, isLoading, isPending } =
    useGetOrdersList({
      pageIndex: 0,
      pageSize: 20,
      orderStatus: filterStatus,
      sortDirection: sortDirection,
      vendorSlug: vendorName
    }) || []

  const pageCount = data?.orderCount || 100

  const columnHelper = createColumnHelper<OrderItem>()

  const table = useReactTable({
    data: data?.orderList || [],
    columns: [
      columnHelper.accessor('orderId', {
        cell: info => {
          info.getValue()

          return (
            <Link className='text-blue-500 font-bold' href={`/order/${info.getValue()}`}>
              {info.getValue() + '\u00A0 # \u00A0'}
            </Link>
          )
        },

        header: 'شناسه'
      }),
      columnHelper.accessor('vendorName', {
        cell: info => info.getValue(),
        header: 'نام فروشگاه'
      }),

      columnHelper.accessor('dateTime', {
        cell: info => {
          const date = info.getValue()

          const fromattedDate = dateFormatter(date)

          return date === null ? '---' : fromattedDate
        },
        header: 'تاریخ '
      }),

      columnHelper.accessor('finalPrice', {
        cell: info => {
          return numeral(info.getValue()).format('0,0')
        },
        header: 'مبلغ سفارش'
      }),

      columnHelper.accessor('orderStatus', {
        cell: info => {
          const orderStatus = info.getValue() as OrderStatusType

          return (
            <StatusChips
              label={orderStatusConstant[orderStatus]}
              color={orderStatusChipsColorConstant[orderStatus] as ChipsColorTypes}
            />
          )
        },
        header: 'وضعیت'
      })
    ],
    manualPagination: true,

    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues()
  })

  const handleChange = (event: ChangeEvent<unknown>, value: number) => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
    setPage(value)
  }

  const handleFilterStatus = (value: OrderStatusFilterType) => {
    setFilterStatus(value)
  }

  const handleSortDirection = (value: OrderSortDirectionType) => {
    setSortDirection(value)
  }

  const handleVendorSlugSearch = (value: string) => {
    setvendorName(value)
  }

  return (
    <Card className='w-full h-full flex flex-col'>
      <div className='flex justify-between items-center'>
        <CardHeader title='لیست سفارشات' />

        <h3 className='pl-6'>{data?.orderCount} سفارش</h3>
      </div>

      <OrdersFilter
        filter={{
          vendorSlug: vendorName,
          setVendorSlug: handleVendorSlugSearch,
          sortDirection,
          handleSortDirection,
          handleFilterStatus
        }}
      />

      <Table
        table={table}
        styles={styles}
        pagination={{ onPagination: handleChange, page, pageCount }}
        isLoading={isLoading || isPending}
      />
    </Card>
  )
}
