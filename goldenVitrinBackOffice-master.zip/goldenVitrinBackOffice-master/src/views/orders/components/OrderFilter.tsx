'use client'

import React, { type ReactElement } from 'react'

import Filter from '@/components/filter'
import type { OrderSortDirectionType, OrderStatusFilterType } from '@/apis/dash/v2/orders/orderList.api'

interface Filters {
  vendorSlug: string
  setVendorSlug: (value: string) => void
  sortDirection: OrderSortDirectionType
  handleSortDirection: (value: OrderSortDirectionType) => void
  handleFilterStatus: (value: OrderStatusFilterType) => void
}

interface Props {
  filter: Filters
}

const statusItems = [
  {
    name: 'همه',
    value: ''
  },

  {
    name: 'در انتظار تایید',
    value: 'Pending'
  },

  {
    name: 'آماده سازی',
    value: 'Processing'
  },

  {
    name: 'رد',
    value: 'Rejected'
  },

  {
    name: 'ارسال شده',
    value: 'Shipped'
  },

  {
    name: 'تحویل',
    value: 'Delivered'
  },

  {
    name: 'پرداخت نشده',
    value: 'WaitForPayment'
  }
]

const sortDirectionItems = [
  {
    name: 'جدید ترین',
    value: 'Descending'
  },

  {
    name: ' قدیمی ترین',
    value: 'Ascending'
  }
]

const OrdersFilter = ({ filter }: Props): ReactElement => {
  return (
    <Filter className='flex w-full h-full justify-between items-center'>
      <div className=' flex gap-x-4 items-center w-full  '>
        <Filter.TextField searchTerm={filter.vendorSlug} setSearchTerm={filter.setVendorSlug} label='نام فروشگاه' />
      </div>

      <div className=' flex gap-x-4 items-center w-full justify-end'>
        <Filter.Select label='وضعیت' items={statusItems} onChange={filter.handleFilterStatus} />

        <Filter.Select
          label='ترتیب نمایش'
          items={sortDirectionItems}
          onChange={filter.handleSortDirection}
          defaultValue={filter.sortDirection}
        />
      </div>
    </Filter>
  )
}

export default OrdersFilter
