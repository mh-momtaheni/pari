'use client'

import type { ChangeEvent, ReactElement } from 'react'
import React, { useState } from 'react'

import Link from 'next/link'

import {
  createColumnHelper,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getPaginationRowModel,
  useReactTable
} from '@tanstack/react-table'

import { Card, CardHeader } from '@mui/material'

import styles from '@core/styles/table.module.css'

import Filter from '@/components/filter'
import Table from '@/components/table'
import type { ChipsColorTypes } from '@/components/chips/chips.component'
import StatusChips from '@/components/chips/chips.component'
import { vendorStatusChipsColorConstant, vendorStatusConstant } from '@/constants/vendor.constant'
import dateFormatter from '@/utils/date-formatter.util'
import { useGetVendorList } from '@/apis/vendor/v2/List.api'

import type {
  VendorsListItem,
  VendorStatusType,
  AllVendorsQueryParams,
  SortConditionType,
  SortDirectionType
} from '@/types/vendor.type'

function Main(): ReactElement {
  const [params, setParams] = useState<AllVendorsQueryParams>({
    pageIndex: 0,
    pageSize: 20,
    sortDirection: 'Descending',
    sortCondition: 'CreatedDate',
    vendorStatus: 'All'
  })

  const { data, isLoading, isPending } =
    useGetVendorList({
      params: params
    }) || []

  const pageCount = data?.data.totalCount || 100
  const columnHelper = createColumnHelper<VendorsListItem>()

  const table = useReactTable({
    data: data?.data?.items || [],
    columns: [
      columnHelper.accessor('id', {
        cell: info => {
          info.getValue()

          return (
            <Link className='text-blue-500 font-bold' href={`/vendors/list/${info.getValue()}`}>
              {info.getValue() + '\u00A0 # \u00A0'}
            </Link>
          )
        },
        header: 'شناسه'
      }),
      columnHelper.accessor('vendorName', {
        cell: info => info.getValue(),
        header: 'نام فروشگاه'
      }),
      columnHelper.accessor('vendorSlug', {
        cell: info => {
          info.getValue()

          return (
            <Link
              target='_blank'
              className='text-blue-500 font-semibold'
              href={`https://witro.shop//${info.getValue()}`}
            >
              {info.getValue()}
            </Link>
          )
        },
        header: 'آدرس فروشگاه'
      }),
      columnHelper.accessor('createdDateTime', {
        cell: info => {
          const date = info.getValue()
          const fromattedDate = dateFormatter(date)

          return date === null ? '---' : fromattedDate
        },
        header: 'تاریخ ساخت'
      }),

      columnHelper.accessor('modifiedDateTime', {
        cell: info => {
          const date = info.getValue()
          const fromattedDate = dateFormatter(date)

          return date === null ? '---' : fromattedDate
        },
        header: 'تاریخ ویرایش'
      }),

      columnHelper.accessor('approveTime', {
        cell: info => {
          const date = info.getValue()
          const fromattedDate = dateFormatter(date)

          return date === null ? '---' : fromattedDate
        },
        header: 'تاریخ تایید'
      }),

      columnHelper.accessor('vendorStatus', {
        cell: info => {
          const status = info.getValue() as VendorStatusType

          return (
            <StatusChips
              label={vendorStatusConstant[status]}
              color={vendorStatusChipsColorConstant[status] as ChipsColorTypes}
            />
          )
        },
        header: 'وضعیت'
      })
    ],
    manualPagination: true,

    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues()
  })

  const handleChange = (event: ChangeEvent<unknown>, value: number) => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
    setParams(prevState => ({
      ...prevState,
      pageIndex: value - 1
    }))
  }

  return (
    <div className=' h-full w-full flex flex-col gap-y-4'>
      <div className='w-full h-full'>
        <Card className='w-full h-full'>
          <div className='flex items-center gap-2'></div>
          <CardHeader title={`تعداد فروشگاه ها : ${data?.data.totalCount || 0} عدد`} />

          <Filter>
            <Filter.Select
              onChange={(value: SortDirectionType) => {
                setParams(prevState => {
                  return { ...prevState, pageIndex: 0, sortDirection: value }
                })
              }}
              label='ترتیب نمایش'
              defaultValue='Descending'
              items={[
                { value: 'Descending', name: 'جدیدترین' },
                { value: 'Ascending', name: 'قدیمی‌ترین' }
              ]}
            />
            <Filter.Select
              onChange={(value: SortConditionType) => {
                setParams(prevState => {
                  return { ...prevState, pageIndex: 0, sortCondition: value }
                })
              }}
              label='مرتب سازی بر اساس'
              defaultValue='CreatedDate'
              items={[
                { value: 'CreatedDate', name: 'تاریخ ساخت' },
                { value: 'ModifiedDate', name: 'تاریخ ویرایش' }
              ]}
            />
            <Filter.Select
              onChange={(value: VendorStatusType) => {
                setParams(prevState => {
                  return { ...prevState, pageIndex: 0, vendorStatus: value }
                })
              }}
              label='وضعیت'
              defaultValue='All'
              items={[
                { value: 'All', name: 'همه' },
                { value: 'Pending', name: 'در انتظار تایید' },
                { value: 'Active', name: 'فعال' },
                { value: 'Inactive', name: 'غیرفعال' },
                { value: 'Rejected', name: 'رد شده' },
                { value: 'Approved', name: 'تایید' }
              ]}
            />
            <Filter.TextField
              searchTerm={params.searchByVendorName ?? ''}
              label='نام فروشگاه'
              setSearchTerm={(value: string) => {
                setParams(prevState => {
                  return { ...prevState, pageIndex: 0, searchByVendorName: value }
                })
              }}
            />
            <Filter.TextField
              searchTerm={params.searchByVendorSlug ?? ''}
              label='آدرس فروشگاه'
              setSearchTerm={(value: string) => {
                setParams(prevState => {
                  return { ...prevState, pageIndex: 0, searchByVendorSlug: value }
                })
              }}
            />
          </Filter>

          <Table
            table={table}
            styles={styles}
            pagination={{ onPagination: handleChange, page: (params?.pageIndex || 0) + 1, pageCount }}
            isLoading={isLoading || isPending}
          />
        </Card>
      </div>
    </div>
  )
}

export default Main
