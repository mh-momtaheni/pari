import React from 'react'

import Main from '@/views/vendorList/components/Main.component'

function VendorList() {
  return <Main />
}

export default VendorList
