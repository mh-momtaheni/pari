export { default as VendorList } from './VendorList.view'
