import React from 'react'

import Main from './component/main.component'

function Product() {
  return <Main />
}

export default Product
