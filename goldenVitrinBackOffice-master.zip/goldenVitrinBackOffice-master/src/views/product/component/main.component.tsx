'use client'

import type { ChangeEvent, ReactElement } from 'react'
import React, { useState } from 'react'

import Link from 'next/link'

import { useSearchParams } from 'next/navigation'

import {
  createColumnHelper,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getPaginationRowModel,
  useReactTable
} from '@tanstack/react-table'

import { Card, CardHeader } from '@mui/material'

import styles from '@core/styles/table.module.css'

import type { ProductItem } from '@/apis/dash/v2/product/productList.api'
import useGetProductList from '@/apis/dash/v2/product/productList.api'
import Table from '@/components/table'
import type { ChipsColorTypes } from '@/components/chips/chips.component'
import StatusChips from '@/components/chips/chips.component'
import type { ProdcutStatusType } from '@/types/productStatus.type'
import dateFormatter from '@/utils/date-formatter.util'
import ProductFilter from './product-filter.component'
import type {
  ProdcutFilterStatusType,
  ProductSortConditionType,
  ProductSortDirectionType
} from '@/types/productFilter.type'
import { productStatusChipsColorConstant, productStatusConstant } from '@/constants/productStatus.constant'

const Main = (): ReactElement => {
  const [page, setPage] = useState<number>(1)
  const [filterStatus, setFilterStatus] = useState<ProdcutFilterStatusType>('All')
  const [sortCondition, setSortCondition] = useState<ProductSortConditionType>('CreatedDate')
  const [sortDirection, setSortDirection] = useState<ProductSortDirectionType>('Descending')
  const [productName, setProductName] = useState<string>('')
  const searchParams = useSearchParams()
  const vendorId = searchParams.get('vendorId')

  const { data, isLoading, isPending } =
    useGetProductList({
      pageIndex: page - 1,
      pageSize: 20,
      productStatus: filterStatus,
      sortCondition: sortCondition,
      sortDirection: sortDirection,
      productName,
      ...(vendorId && { vendorId: Number(vendorId) })
    }) || []

  const pageCount = data?.productCount || 100

  const columnHelper = createColumnHelper<ProductItem>()

  const table = useReactTable({
    data: data?.vendorProducts || [],
    columns: [
      columnHelper.accessor('id', {
        cell: info => {
          info.getValue()

          return (
            <Link className='text-blue-500 font-bold' href={`/product/${info.getValue()}`}>
              {info.getValue() + '\u00A0 # \u00A0'}
            </Link>
          )
        },

        header: 'شناسه'
      }),
      columnHelper.accessor('name', {
        cell: info => info.getValue(),
        header: 'نام محصول'
      }),
      columnHelper.accessor('vendorName', {
        cell: info => info.getValue(),

        header: 'نام فروشگاه'
      }),
      columnHelper.accessor('createdDateTime', {
        cell: info => {
          const date = info.getValue()

          const fromattedDate = dateFormatter(date)

          return date === null ? '---' : fromattedDate
        },
        header: 'تاریخ ساخت'
      }),

      columnHelper.accessor('modifiedDateTime', {
        cell: info => {
          const date = info.getValue()

          const fromattedDate = dateFormatter(date)

          return date === null ? '---' : fromattedDate
        },
        header: 'تاریخ ویرایش'
      }),

      columnHelper.accessor('approvedDateTime', {
        cell: info => {
          const date = info.getValue()

          const fromattedDate = dateFormatter(date)

          return date === null ? '---' : fromattedDate
        },
        header: 'تاریخ تایید'
      }),

      columnHelper.accessor('productStatus', {
        cell: info => {
          const status = info.getValue() as ProdcutStatusType

          return (
            <StatusChips
              label={productStatusConstant[status]}
              color={productStatusChipsColorConstant[status] as ChipsColorTypes}
            />
          )
        },
        header: 'وضعیت'
      })
    ],
    manualPagination: true,

    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues()
  })

  const handleChange = (event: ChangeEvent<unknown>, value: number) => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
    setPage(value)
  }

  const handleFilterStatus = (value: ProdcutFilterStatusType) => {
    setFilterStatus(value)

    setPage(1)
  }

  const handleSortCondition = (value: ProductSortConditionType) => {
    setSortCondition(value)
  }

  const handleSortDirection = (value: ProductSortDirectionType) => {
    setSortDirection(value)
  }

  const handleProductNameSearch = (value: string) => {
    setProductName(value)
  }

  return (
    <Card className='w-full h-full flex flex-col'>
      <div className='flex justify-between items-center'>
        <CardHeader title='لیست محصولات' />

        <h3 className='pl-6'>{data?.productCount} محصول</h3>
      </div>

      <ProductFilter
        filter={{
          filterStatus,
          handleFilterStatus,
          sortCondition,
          handleSortCondition,
          sortDirection,
          handleSortDirection,
          productName,
          handleProductNameSearch
        }}
      />

      <Table
        table={table}
        styles={styles}
        pagination={{ onPagination: handleChange, page, pageCount }}
        isLoading={isLoading || isPending}
      />
    </Card>
  )
}

export default Main
