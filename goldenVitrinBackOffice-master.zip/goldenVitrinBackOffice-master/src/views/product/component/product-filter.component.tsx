'use client'

import React, { type ReactElement } from 'react'

import Filter from '@/components/filter'
import type {
  ProdcutFilterStatusType,
  ProductSortConditionType,
  ProductSortDirectionType
} from '@/types/productFilter.type'

interface Filters {
  filterStatus: string
  handleFilterStatus: (value: ProdcutFilterStatusType) => void
  sortCondition: string
  handleSortCondition: (value: ProductSortConditionType) => void
  sortDirection: string
  handleSortDirection: (value: ProductSortDirectionType) => void
  productName: string
  handleProductNameSearch: (value: string) => void
}

interface Props {
  filter: Filters
}

const statusItems = [
  {
    name: 'همه',
    value: 'All'
  },

  {
    name: 'در انتظار تایید',
    value: 'Pending'
  },

  {
    name: 'ساخته شده',
    value: 'Created'
  },

  {
    name: 'رد',
    value: 'NotApproved'
  },

  {
    name: 'تایید',
    value: 'Approved'
  }
]

const sortItems = [
  {
    name: 'ناریخ ساخت',
    value: 'CreatedDate'
  },

  {
    name: 'تاریخ ویرایش',
    value: 'modifiedDate'
  },

  {
    name: 'قیمت',
    value: 'Price'
  }
]

const sortDirectionItems = [
  {
    name: 'جدید ترین',
    value: 'Descending'
  },

  {
    name: ' قدیمی ترین',
    value: 'Ascending'
  }
]

const ProductFilter = ({ filter }: Props): ReactElement => {
  return (
    <Filter className='flex w-full h-full justify-between items-center'>
      <div className=' flex gap-x-4 items-center w-full  '>
        <Filter.Select
          label='وضعیت'
          items={statusItems}
          onChange={filter.handleFilterStatus}
          defaultValue={filter.filterStatus}
        />

        <Filter.TextField
          searchTerm={filter.productName}
          setSearchTerm={filter.handleProductNameSearch}
          label='نام محصول'
        />
      </div>

      <div className=' flex gap-x-4 items-center w-full justify-end'>
        <Filter.Select
          label='مرتب سازی بر اساس'
          items={sortItems}
          onChange={filter.handleSortCondition}
          defaultValue={filter.sortCondition}
        />

        <Filter.Select
          label='ترتیب نمایش'
          items={sortDirectionItems}
          onChange={filter.handleSortDirection}
          defaultValue={filter.sortDirection}
        />
      </div>
    </Filter>
  )
}

export default ProductFilter
