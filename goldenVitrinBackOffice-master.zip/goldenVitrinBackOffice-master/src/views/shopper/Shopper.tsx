import MainComponent from './components/ShopperMain.component'

export default function ShoppersList() {
  return <MainComponent />
}
