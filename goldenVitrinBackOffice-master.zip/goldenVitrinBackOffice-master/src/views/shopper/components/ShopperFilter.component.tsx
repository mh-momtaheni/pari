import React from 'react'

import Filter from '@/components/filter'
import type { ShopperListParams } from '@/apis/dash/v2/shoppers/shoppers-list.api'

function ShopperListFilter({
  params,
  setParams
}: {
  params: ShopperListParams
  setParams: (value: ShopperListParams) => void
}) {
  return (
    <Filter>
      <Filter.Select
        onChange={(value: string) => setParams({ ...params, SortDirection: value })}
        defaultValue={params.SortDirection}
        label='ترتیب نمایش'
        items={[
          { value: 'Descending', name: 'جدیدترین' },
          { value: 'Ascending', name: 'قدیمی ترین' }
        ]}
      />
      <Filter.Select
        onChange={(value: string) => setParams({ ...params, SortCondition: value })}
        defaultValue={params.SortCondition ?? ''}
        label='مرتب سازی بر اساس '
        items={[
          { value: 'CreatedDate', name: 'جدید ترین تاریخ ساخت' },
          { value: 'ModifiedDate', name: 'جدید ترین تاریخ ویرایش ' }
        ]}
      />
      <Filter.TextField
        searchTerm={params.PhoneNumber ?? ''}
        label='شماره موبایل'
        setSearchTerm={(value: string) => setParams({ ...params, PhoneNumber: value })}
      />
    </Filter>
  )
}

export default ShopperListFilter
