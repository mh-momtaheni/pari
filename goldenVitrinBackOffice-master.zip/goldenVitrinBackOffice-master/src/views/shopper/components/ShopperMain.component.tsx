/* eslint-disable react-hooks/exhaustive-deps */
'use client'

import type { ChangeEvent } from 'react'
import React, { useState } from 'react'

import Card from '@mui/material/Card'
import {
  createColumnHelper,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getPaginationRowModel,
  useReactTable
} from '@tanstack/react-table'

import styles from '@core/styles/table.module.css'
import TableComponent from '@/components/table/components/main.component'
import dateFormatter from '@/utils/date-formatter.util'
import type { ResponseData, ShopperListParams } from '@/apis/dash/v2/shoppers/shoppers-list.api'
import { useGetShoppersList } from '@/apis/dash/v2/shoppers/shoppers-list.api'

import ShopperListFilter from './ShopperFilter.component'

export interface DataType {
  id: number
  firstName: string
  lastName: string
  phoneNumber: string
  createdDateTime: string
  modifiedDateTime: string
}

export default function Main() {
  const columnHelper = createColumnHelper<ResponseData>()
  const [page, setPage] = useState(0)

  const [params, setParams] = useState<ShopperListParams>({
    SortDirection: 'Descending',
    PageIndex: page,
    PageSize: 20
  })

  const { data: shopperList, isPending } = useGetShoppersList(params)

  const table = useReactTable({
    data: shopperList?.data.items || [],
    columns: [
      columnHelper.accessor('id', {
        cell: info => info.getValue(),
        header: 'شناسه'
      }),
      columnHelper.accessor('firstName', {
        cell: info => info.getValue(),
        header: 'نام'
      }),
      columnHelper.accessor('lastName', {
        cell: info => info.getValue(),
        header: 'نام خانوادگی'
      }),
      columnHelper.accessor('phoneNumber', {
        cell: info => info.getValue(),
        header: 'شماره موبایل'
      }),
      columnHelper.accessor('createdDateTime', {
        cell: info => {
          const date = info.getValue()

          return dateFormatter(date)
        },
        header: 'تاریخ ساخت'
      }),
      columnHelper.accessor('modifiedDateTime', {
        cell: info => {
          const date = info.getValue()

          return dateFormatter(date)
        },
        header: 'تاریخ ویرایش'
      })
    ],
    manualPagination: true,
    initialState: {
      pagination: {
        pageSize: 20,
        pageIndex: 0
      }
    },
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues()
  })

  const onPageChangeHandler = (_index: ChangeEvent<unknown>, pageIndex: number) => {
    setPage(pageIndex)
  }

  return (
    <Card>
      <ShopperListFilter
        params={params}
        setParams={(newParam: ShopperListParams) => {
          setParams(newParam)
        }}
      />

      <div className='overflow-x-auto'>
        <TableComponent
          isLoading={isPending}
          table={table}
          styles={styles}
          pagination={{ page, pageCount: shopperList?.totalCount ?? 100, onPagination: onPageChangeHandler }}
        />
      </div>
    </Card>
  )
}
