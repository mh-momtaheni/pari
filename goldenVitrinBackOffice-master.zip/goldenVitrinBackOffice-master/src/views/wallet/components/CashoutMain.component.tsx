/* eslint-disable react-hooks/exhaustive-deps */
'use client'

import type { ChangeEvent } from 'react'
import React, { useEffect, useState } from 'react'

import numeral from 'numeral'
import Card from '@mui/material/Card'
import CardHeader from '@mui/material/CardHeader'
import {
  createColumnHelper,
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getPaginationRowModel,
  useReactTable
} from '@tanstack/react-table'

import styles from '@core/styles/table.module.css'
import type { DataType, ParamsType } from '@/apis/dash/v1/wallet/cashoutList.api'
import { useGetCashoutList } from '@/apis/dash/v1/wallet/cashoutList.api'
import TableComponent from '@/components/table/components/main.component'
import dateFormatter from '@/utils/date-formatter.util'
import StatusChips from '@/components/chips'
import { walletStatusChipsColorConstant, walletStatusConstant } from '@/constants/wallet-status.constant'
import type { ChipsColorTypes } from '@/components/chips/chips.component'

import FilterComponent from './CashoutFilter.component'
import { useGetExcel } from '@/hooks/useGetExcel'

function Main() {
  const columnHelper = createColumnHelper<DataType>()
  const [data, setData] = useState<DataType[] | []>([])
  const [searchName, setSearchName] = useState('')
  const [page, setPage] = useState(0)

  const [params, setParams] = useState<ParamsType>({
    startDate: '2023-05-25T14:46:02.644Z',
    endDate: '2024-05-27T14:46:02.644Z',
    pageIndex: page,
    pageSize: 20,
    firstName: searchName,
    sortDirection: 'Descending',
    cashoutType: 'Requested'
  })

  const { mutate: getExcel } = useGetExcel({ params, url: '/Dash/v1/Wallet/CashOutExcel' })

  function resetTimeToMidnight(dateString: string) {
    const date = new Date(dateString)

    date.setUTCHours(0, 0, 0, 0)

    return date.toISOString().split('.')[0] + 'Z'
  }

  const table = useReactTable({
    data,
    columns: [
      columnHelper.accessor('cashoutId', {
        cell: info => info.getValue(),
        header: 'شناسه'
      }),
      columnHelper.accessor('name', {
        cell: info => info.getValue(),
        header: 'نام و نام خانوادگی'
      }),
      columnHelper.accessor('amount', {
        cell: info => {
          const amount = info.getValue()

          return numeral(amount).format('0,0')
        },
        header: 'مبلغ (ریال)'
      }),
      columnHelper.accessor('createDateTime', {
        cell: info => {
          const date = info.getValue()

          return dateFormatter(date)
        },
        header: 'تاریخ درخواست'
      }),
      columnHelper.accessor('phoneNumber', {
        cell: info => info.getValue(),
        header: 'شماره موبایل'
      }),
      columnHelper.accessor('iban', {
        cell: info => info.getValue(),
        header: 'شماره شبا'
      }),
      columnHelper.accessor('cashOutStatus', {
        cell: info => {
          const status = info.getValue()

          return (
            <StatusChips
              label={walletStatusConstant[status]}
              color={walletStatusChipsColorConstant[status] as ChipsColorTypes}
            />
          )
        },
        header: 'وضعیت'
      })
    ],
    manualPagination: true,
    initialState: {
      pagination: {
        pageSize: 20,
        pageIndex: 0
      }
    },
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues()
  })

  const { mutate: getCashoutList, data: cashoutData, isPending } = useGetCashoutList(params)

  const onPageChangeHandler = (_index: ChangeEvent<unknown>, pageIndex: number) => {
    setPage(pageIndex)
  }

  const handleSearchName = (value: string) => {
    setSearchName(value)
    setParams({ ...params, firstName: value })
  }

  const startDateHandler = (value: string) => {
    setParams({ ...params, startDate: resetTimeToMidnight(value) })
  }

  const endDateHandler = (value: string) => {
    setParams({ ...params, endDate: resetTimeToMidnight(value) })
  }

  useEffect(() => {
    getCashoutList()
  }, [params])

  useEffect(() => {
    if (cashoutData) {
      setData(cashoutData.data.cashoutListResList)
    }
  }, [cashoutData])

  const clickHandler = () => {
    getExcel()
  }

  return (
    <Card>
      <CardHeader title='لیست درخواست وجه' />
      <FilterComponent
        searchName={searchName}
        setSearchName={handleSearchName}
        params={params}
        setStartDate={startDateHandler}
        setEndDate={endDateHandler}
      />

      <div className='overflow-x-auto'>
        <TableComponent
          isLoading={isPending}
          table={table}
          styles={styles}
          excelFunction={clickHandler}
          pagination={{ page, pageCount: cashoutData?.data.count ?? 100, onPagination: onPageChangeHandler }}
        />
      </div>
    </Card>
  )
}

export default Main
