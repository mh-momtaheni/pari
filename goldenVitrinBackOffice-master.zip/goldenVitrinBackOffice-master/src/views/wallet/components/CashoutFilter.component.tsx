import React from 'react'

import Filter from '@/components/filter'
import type { ParamsType } from '@/apis/dash/v1/wallet/cashoutList.api'

type VoidFunction = (val: string) => void

export interface FilterComponentProps {
  searchName: string
  setSearchName: VoidFunction
  params: ParamsType
  setStartDate: VoidFunction
  setEndDate: VoidFunction
}

function FilterComponent({ searchName, setSearchName, params, setStartDate, setEndDate }: FilterComponentProps) {
  const { startDate } = params

  return (
    <div className='flex justify-between w-full items-center'>
      <Filter className='flex justify-between w-full'>
        <Filter.TextField searchTerm={searchName} setSearchTerm={value => setSearchName(value)} label='تراکنش' />
        <div className='flex gap-4'>
          <Filter.DatePicker label='از تاریخ' date={startDate} setDate={(value: string) => setStartDate(value)} />
          <Filter.DatePicker label='تا تاریخ' date={params.endDate} setDate={(value: string) => setEndDate(value)} />
        </div>
      </Filter>
    </div>
  )
}

export default FilterComponent
