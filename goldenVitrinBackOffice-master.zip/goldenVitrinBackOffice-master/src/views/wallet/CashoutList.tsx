import React from 'react'

import CashoutMain from './components/CashoutMain.component'

function WalletManagement() {
  return <CashoutMain />
}

export default WalletManagement
