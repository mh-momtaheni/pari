import React from 'react'

import Main from '@/views/vendor-detail/components/Main.component'

function VendorDetail() {
  return <Main />
}

export default VendorDetail
