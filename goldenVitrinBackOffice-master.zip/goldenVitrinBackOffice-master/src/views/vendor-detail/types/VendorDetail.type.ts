import type { VendorLogoType, VendorStatusType } from '@/types/vendor.type'

export interface VendorHeaderType {
  id: number | undefined
  vendorName: string | undefined
  slug: string | undefined
  aboutMe: string | undefined
  vendorLogo: VendorLogoType | undefined
}

export interface VendorSectionType {
  createdDateTime: string | undefined
  modifiedDateTime: string | undefined
  approveTime: string | undefined
  vendorStatus: VendorStatusType | undefined
  packageName: string | undefined
  anyProductAdded: boolean | undefined
  anyProductApproved: boolean | undefined
  vendorOwnerAdditionalInformationCompleted: boolean | undefined
  vendorShippingFeeSubmitted: boolean | undefined
  anyActivePurchasedPackage: boolean | undefined
}

export interface ProfileSectionType {
  userId: number | undefined
  firstName: string | undefined
  lastName: string | undefined
  nationalCode: string | undefined
  phoneNumber: string | undefined
  provinceName: string | undefined
  cityName: string | undefined
  address: string | undefined
  postalCode: string | undefined
}
