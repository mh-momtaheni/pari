export { default } from './VendorDetail.view'
