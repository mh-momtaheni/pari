'use client'
import React, { useEffect, useState } from 'react'

// MUI Imports
import Card from '@mui/material/Card'
import Typography from '@mui/material/Typography'
import List from '@mui/material/List'
import ListItem from '@mui/material/ListItem'
import ListItemText from '@mui/material/ListItemText'
import Divider from '@mui/material/Divider'
import CardContent from '@mui/material/CardContent'

import dateFormatter from '@/utils/date-formatter.util'

// import StatusChips from '@/components/chips/chips.component'
import CustomChip from '@core/components/mui/Chip'
import { vendorStatusChipsColorConstant, vendorStatusConstant } from '@/constants/vendor.constant'
import type { ChipsColorTypes } from '@/components/chips/chips.component'

import type { VendorSectionType } from '@/views/vendor-detail/types/VendorDetail.type'

interface Item {
  label: React.ReactNode
  value: React.ReactNode
}

function VendorSection({ data }: { data: VendorSectionType }) {
  const [items, setItems] = useState<Item[]>([])

  useEffect(() => {
    const formattedItems: Item[] = [
      { label: 'تاریخ ساخت :', value: data.createdDateTime ? dateFormatter(data.createdDateTime) : '--------' },
      { label: 'تاریخ ویرایش :', value: data.modifiedDateTime ? dateFormatter(data.modifiedDateTime) : '--------' },
      { label: 'تاریخ تایید :', value: data.approveTime ? dateFormatter(data.approveTime) : '--------' },
      { label: 'پکیج فعال :', value: data.packageName ? data.packageName : '--------' },
      {
        label: 'وضعیت فروشگاه :',
        value: data.vendorStatus ? (
          <CustomChip
            label={vendorStatusConstant[data.vendorStatus]}
            color={vendorStatusChipsColorConstant[data.vendorStatus] as ChipsColorTypes}
          />
        ) : (
          '--------'
        )
      },
      {
        label: 'محصولی اضافه شده ؟',
        value: data.anyProductAdded ? (
          <i className='tabler-check text-green-500' />
        ) : (
          <i className='tabler-x text-red-500' />
        )
      },
      {
        label: 'محصولی تایید شده ؟',
        value: data.anyProductApproved ? (
          <i className='tabler-check text-green-500' />
        ) : (
          <i className='tabler-x text-red-500' />
        )
      },
      {
        label: 'اطلاعات فروشنده تکمیل شده ؟',
        value: data.vendorOwnerAdditionalInformationCompleted ? (
          <i className='tabler-check text-green-500' />
        ) : (
          <i className='tabler-x text-red-500' />
        )
      },
      {
        label: 'هزینه ارسال تعیین شده ؟',
        value: data.vendorShippingFeeSubmitted ? (
          <i className='tabler-check text-green-500' />
        ) : (
          <i className='tabler-x text-red-500' />
        )
      },
      {
        label: 'بسته اشتراک انتخاب شده ؟',
        value: data.anyActivePurchasedPackage ? (
          <i className='tabler-check text-green-500' />
        ) : (
          <i className='tabler-x text-red-500' />
        )
      }
    ]

    setItems(formattedItems)
  }, [data])

  return (
    <Card>
      <CardContent className='flex gap-5 justify-center flex-col items-center md:items-start md:mt-6 md:flex-row !pt-0 md:justify-center'>
        <div className='w-full h-full flex flex-col'>
          <div className='flex gap-2 justify-start items-center h-full w-full pb-3 mt-5 md:mt-0 '>
            <i className='tabler-brand-appgallery' />
            <Typography className='translate-y-[2px]' variant='h5'>
              مشخصات فروشگاه
            </Typography>
          </div>
          <Divider variant='fullWidth' />
          <div className='rtl'>
            <List>
              {items.map((item, index) => (
                <ListItem key={index} className='justify-start'>
                  <ListItemText
                    className='flex justify-between items-center'
                    primary={item.label}
                    secondary={item.value}
                    secondaryTypographyProps={{ fontSize: '15px', fontWeight: '500', textAlign: 'right' }}
                  />
                </ListItem>
              ))}
            </List>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default VendorSection
