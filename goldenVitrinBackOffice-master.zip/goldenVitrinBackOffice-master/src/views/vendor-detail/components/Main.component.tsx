'use client'

import { usePathname } from 'next/navigation'

import Grid from '@mui/material/Grid'

import { useGetVendorDetail } from '@/apis/vendor/v2/Detail.api'

import type {
  ProfileSectionType,
  VendorHeaderType,
  VendorSectionType
} from '@/views/vendor-detail/types/VendorDetail.type'

import VendorHeader from '@/views/vendor-detail/components/VendorHeader.component'
import VendorSection from '@/views/vendor-detail/components/VendorSection.component'
import ProfileSection from '@/views/vendor-detail/components/ProfileSection.component'

const Main = () => {
  const pathName = usePathname().split('/')[3]

  const { data: vendor } =
    useGetVendorDetail({
      id: pathName
    }) || []

  const headerData: VendorHeaderType = {
    id: vendor?.id,
    vendorName: vendor?.vendorName,
    slug: vendor?.slug,
    aboutMe: vendor?.aboutMe,
    vendorLogo: vendor?.logo?.vendorLogo
  }

  const vendorData: VendorSectionType = {
    createdDateTime: vendor?.createdDateTime || undefined,
    modifiedDateTime: vendor?.modifiedDateTime || undefined,
    approveTime: vendor?.approveTime || undefined,
    vendorStatus: vendor?.vendorStatus || undefined,
    packageName: vendor?.packagePurchase.packageName || undefined,
    anyProductAdded: vendor?.condition.anyProductAdded || undefined,
    anyProductApproved: vendor?.condition.anyProductApproved || undefined,
    vendorOwnerAdditionalInformationCompleted: vendor?.condition.vendorOwnerAdditionalInformationCompleted || undefined,
    vendorShippingFeeSubmitted: vendor?.condition.vendorShippingFeeSubmitted || undefined,
    anyActivePurchasedPackage: vendor?.condition.anyActivePurchasedPackage || undefined
  }

  const profileData: ProfileSectionType = {
    userId: vendor?.userId,
    firstName: vendor?.firstName || undefined,
    lastName: vendor?.lastName || undefined,
    nationalCode: vendor?.nationalCode || undefined,
    phoneNumber: vendor?.phoneNumber,
    provinceName: vendor?.vendorAddress?.provinceName || undefined,
    cityName: vendor?.vendorAddress?.cityName || undefined,
    address: vendor?.vendorAddress?.address || undefined,
    postalCode: vendor?.vendorAddress?.postalCode || undefined
  }

  return (
    <Grid container spacing={6} gap={4}>
      <Grid item xs={12}>
        <VendorHeader data={headerData} />
      </Grid>
      <Grid container xs={12} spacing={6}>
        <Grid item xs={12} md={6}>
          <VendorSection data={vendorData} />
        </Grid>
        <Grid item xs={12} md={6}>
          <ProfileSection data={profileData} />
        </Grid>
      </Grid>
    </Grid>
  )
}

export default Main
