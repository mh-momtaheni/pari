import classNames from 'classnames'

// MUI Imports
import Card from '@mui/material/Card'
import Typography from '@mui/material/Typography'
import List from '@mui/material/List'
import ListItem from '@mui/material/ListItem'
import ListItemText from '@mui/material/ListItemText'
import Divider from '@mui/material/Divider'
import CardContent from '@mui/material/CardContent'

import type { ProfileSectionType } from '@/views/vendor-detail/types/VendorDetail.type'

// import CardMedia from '@mui/material/CardMedia'
interface Item {
  label: React.ReactNode
  value: React.ReactNode
  className?: string
}

function ProfileSection({ data }: { data: ProfileSectionType }) {
  const items: Item[] = [
    { label: 'شناسه کاربر :', value: data.userId || '--------' },
    { label: 'نام و نام خانوادگی :', value: data.firstName ? `${data.firstName} ${data.lastName}` : '--------' },
    { label: 'کد ملی :', value: data.nationalCode || '--------' },
    { label: 'شماره موبایل :', value: data.phoneNumber || '--------' },
    { label: 'استان :', value: data.provinceName || '--------' },
    { label: 'شهر :', value: data.cityName || '--------' },
    { label: 'کد پستی :', value: data.postalCode || '--------' }
  ]

  return (
    <Card>
      <CardContent className='flex gap-5 justify-center flex-col items-center md:items-start md:mt-6 md:flex-row !pt-0 md:justify-center'>
        <div className='w-full h-full flex flex-col'>
          <div className='flex gap-2 justify-start items-center h-full w-full pb-3 mt-5 md:mt-0 '>
            <i className='tabler-user' />
            <Typography className='translate-y-[2px]' variant='h5'>
              مشخصات فروشنده
            </Typography>
          </div>
          <Divider variant='fullWidth' />
          <div className='rtl'>
            <List>
              {items.map((item, index) => (
                <ListItem key={index} className='justify-start'>
                  <ListItemText
                    className={classNames(`flex justify-between items-center gap-2`, item.className)}
                    primary={item.label}
                    primaryTypographyProps={{ flexShrink: 0 }}
                    secondary={item.value}
                    secondaryTypographyProps={{
                      fontSize: '15px',
                      fontWeight: '500',
                      textAlign: 'left',
                      width: '100%'
                    }}
                  />
                </ListItem>
              ))}
              <ListItem className='justify-start'>
                <ListItemText
                  className={`flex justify-between items-center gap-2 flex-col`}
                  primary='آدرس محل سکونت :'
                  primaryTypographyProps={{ flexShrink: 0, textAlign: 'right', width: '100%' }}
                  secondary={data.address || '--------'}
                  secondaryTypographyProps={{
                    fontSize: '15px',
                    fontWeight: '500',
                    textAlign: 'left',
                    width: '100%'
                  }}
                />
              </ListItem>
            </List>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default ProfileSection
