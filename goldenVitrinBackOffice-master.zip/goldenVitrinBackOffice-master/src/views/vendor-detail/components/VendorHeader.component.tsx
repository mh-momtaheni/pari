'use client'
import { useEffect } from 'react'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

import { toast } from 'react-toastify'
import { useQueryClient } from '@tanstack/react-query'

// MUI Imports
import Card from '@mui/material/Card'

// import CardMedia from '@mui/material/CardMedia'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import LoadingButton from '@mui/lab/LoadingButton'
import CircularProgress from '@mui/material/CircularProgress'

import { Button } from '@mui/material'

import type { VendorHeaderType } from '@/views/vendor-detail/types/VendorDetail.type'

import { useApproveVendor } from '@/apis/vendor/v2/Approve.api'
import RejectionDialog from './RejectionDialog.component'
import { createQueryStringUtility } from '@/utils/create-query-string.utility'

const VendorHeader = ({ data }: { data: VendorHeaderType }) => {
  const queryClient = useQueryClient()
  const vendorId = usePathname().split('/')[3]

  const {
    mutate: approveVendor,
    isPending: isApprovePending,
    isSuccess: isApproveSuccess
  } = useApproveVendor({ id: vendorId })

  const aproveVendorHandler = () => {
    approveVendor()
  }

  useEffect(() => {
    if (isApproveSuccess) {
      queryClient.invalidateQueries({ queryKey: ['vendor-detail'] })
      toast.success('فروشگاه با موفقیت تایید شد.')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isApproveSuccess])

  return (
    <Card>
      <CardContent className='flex gap-5 justify-center flex-col items-center md:items-start md:mt-6 md:flex-row !pt-0 md:justify-center'>
        <div className='mt-6 md:mt-0 w-[120px] h-[120px]'>
          {data.vendorLogo?.url ? (
            <img
              height={120}
              width={120}
              src={data.vendorLogo?.url}
              className='rounded-full'
              alt='Profile Background'
            />
          ) : (
            <div className='bg-gray-300 w-[120px] h-[120px] rounded-lg'></div>
          )}
        </div>
        <div className='flex is-full justify-start self-end flex-col items-center gap-6 sm-gap-0 sm:flex-row sm:justify-between sm:items-end '>
          <div className='flex flex-col items-center sm:items-start gap-3'>
            <Typography variant='h4'>{data.vendorName}</Typography>
            <div className='flex flex-wrap gap-6 justify-center sm:justify-normal'>
              <div className='flex items-center gap-1'>
                <i className='tabler-grid-3x3' />
                <Typography className='font-semibold translate-y-1'>{data.id || '--------'}</Typography>
              </div>
              <Link
                href={`https://witro.shop/${data.slug}`}
                target='_blank'
                className='font-semibold translate-y-1 text-blue-500 flex items-center gap-1'
              >
                <i className='tabler-link' />
                {data.slug || '--------'}
              </Link>
            </div>
            <div className='flex items-start gap-1'>
              <i className='tabler-align-right  shrink-0' />
              <Typography className='font-medium '>{data.aboutMe || '--------'}</Typography>
            </div>
            <Button
              variant='contained'
              fullWidth
              href={`https://panel.witro.ir/product/list${createQueryStringUtility({ vendorId: vendorId })}`}
              target='_blank'
            >
              مشاهده محصولات فروشگاه
            </Button>
          </div>

          <div className='flex gap-2 flex-col my-auto'>
            <LoadingButton
              loading={isApprovePending}
              disabled={isApprovePending}
              loadingIndicator={<CircularProgress size={20} color='primary' />}
              onClick={aproveVendorHandler}
              variant='contained'
              className='flex gap-1 shrink-0'
              color='info'
            >
              <i className='tabler-check !text-base'></i>
              <span>تایید</span>
            </LoadingButton>
            <RejectionDialog vendorId={vendorId} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default VendorHeader
