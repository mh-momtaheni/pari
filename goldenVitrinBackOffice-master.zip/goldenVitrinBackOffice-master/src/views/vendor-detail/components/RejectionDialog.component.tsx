'use client'
import React, { useState, useEffect } from 'react'

import { useQueryClient } from '@tanstack/react-query'
import type { SubmitHandler } from 'react-hook-form'
import { useForm } from 'react-hook-form'
import { toast } from 'react-toastify'

// MUI Imports
import LoadingButton from '@mui/lab/LoadingButton'
import Dialog from '@mui/material/Dialog'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import DialogActions from '@mui/material/DialogActions'
import DialogContentText from '@mui/material/DialogContentText'
import CircularProgress from '@mui/material/CircularProgress'

import CustomTextField from '@core/components/mui/TextField'

// API Imports

import { useRejectVendor } from '@/apis/vendor/v2/Reject.api'

type Inputs = {
  RejectionReason: string
}

function RejectionDialog({ vendorId }: { vendorId: string }) {
  const queryClient = useQueryClient()
  const [open, setOpen] = useState<boolean>(false)
  const { mutate: rejectVendor, isPending: isRejectPending, isSuccess: isRejectSuccess } = useRejectVendor()

  const {
    register,
    reset,
    handleSubmit,
    formState: { errors }
  } = useForm<Inputs>()

  const handleClickOpen = () => setOpen(true)

  const handleClose = () => {
    setOpen(false)
    reset()
  }

  const rejectVendorHandler = (reason: string) => {
    rejectVendor({ id: vendorId, reasonForRejection: reason })
  }

  const onSubmit: SubmitHandler<Inputs> = data => rejectVendorHandler(data.RejectionReason)

  useEffect(() => {
    if (isRejectSuccess) {
      reset()
      queryClient.invalidateQueries({ queryKey: ['vendor-detail'] })
      toast.success('فروشگاه مورد نظر رد شد.')
      setOpen(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isRejectSuccess])

  return (
    <>
      <LoadingButton onClick={handleClickOpen} variant='outlined' className='flex gap-2 shrink-0' color='error'>
        <i className='tabler-x !text-base'></i>
        <span>رد</span>
      </LoadingButton>
      <Dialog fullWidth open={open} onClose={handleClose} aria-labelledby='form-dialog-title'>
        <form onSubmit={handleSubmit(onSubmit)}>
          <DialogTitle className='text-red-500' id='form-dialog-title'>
            رد فروشگاه
          </DialogTitle>
          <DialogContent>
            <DialogContentText className='mbe-3'>دلیل رد فروشگاه مورد نظر را در کادر زیر وارد کنید :</DialogContentText>
            <CustomTextField
              rows={2}
              multiline
              autoFocus
              fullWidth
              {...register('RejectionReason', { required: true })}
            />
            {errors.RejectionReason && <span className='text-sm text-red-500 mt-2 block'>این فیلد الزامی است</span>}
          </DialogContent>
          <DialogActions className='dialog-actions-dense'>
            <LoadingButton onClick={handleClose}>بستن</LoadingButton>
            <LoadingButton
              type='submit'
              variant='tonal'
              color='error'
              loading={isRejectPending}
              loadingIndicator={<CircularProgress size={20} color='error' />}
            >
              تایید
            </LoadingButton>
          </DialogActions>
        </form>
      </Dialog>
    </>
  )
}

export default RejectionDialog
