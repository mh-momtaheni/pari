export function matchesAny(str: string, patterns: Array<string | RegExp>): boolean {
  return patterns.some(pattern => {
    if (typeof pattern === 'string') {
      // If the pattern is a string, simply check for exact match
      return str === pattern
    } else if (pattern instanceof RegExp) {
      // If the pattern is a regular expression, test the string against it
      return pattern.test(str)
    }

    return false // Return false for any other type of pattern
  })
}
