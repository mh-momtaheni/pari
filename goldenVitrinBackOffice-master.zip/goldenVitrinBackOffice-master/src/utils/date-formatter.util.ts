import dayjs, { extend } from 'dayjs'

import jalaliday from 'jalaliday'

extend(jalaliday)

const dateFormatter = (date: string) => {
  const fromattedDate = dayjs(date).calendar('jalali').locale('fa').format('HH:mm - DD MMMM ')

  return fromattedDate
}

export default dateFormatter
