/* eslint-disable @typescript-eslint/no-unused-vars */
import type { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'

import { login } from '@/apis/identity/v1/login.api'

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      // The name to display on the sign in form (e.g. "Sign in with...")
      name: 'credentials',

      // `credentials` is used to generate a form on the sign in page.
      // You can specify which fields should be submitted, by adding keys to the `credentials` object.
      // e.g. domain, username, password, 2FA token, etc.
      // You can pass any HTML attribute to the <input> tag through the object.
      credentials: {
        username: { label: 'Username', type: 'text' },
        password: { label: 'Password', type: 'text' }
      },
      async authorize(credentials) {
        // Add logic here to look up the user from the credentials supplied

        try {
          if (credentials?.username && credentials.password) {
            const result = await login({
              userName: credentials?.username,
              password: credentials?.password
            })

            const { token, expiresIn, refreshToken, tokenType } = result.data.token

            const user = {
              id: (Math.random() * 100).toString(),
              userName: credentials?.username,
              email: null,
              token,
              expiresIn,
              refreshToken,
              tokenType
            }

            if (user.token) {
              // Any object returned will be saved in `user` property of the JWT
              return user
            }
          }
        } catch (err: any) {
          const { data } = err.response
          const { message } = data.error

          throw new Error(message)
        }

        return null
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      return { ...token, ...user }
    },
    async session({ session, token }) {
      session.user = token as any

      return session
    }
  }
}
