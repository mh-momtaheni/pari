type CreateQueryStringUtilityParams = Record<string, string | number | Array<string | number> | undefined | boolean>

type CreateQueryStringUtilityReturn = string

export function createQueryStringUtility(params: CreateQueryStringUtilityParams): CreateQueryStringUtilityReturn {
  let result = ''

  const queryString = Object.entries(params)
    .map(([key, value]) => {
      if (value !== undefined) {
        if (Array.isArray(value)) {
          return value
            .map(item => item && `${key}=${item}`)
            .filter(item => item)
            .join('&')
        } else {
          return `${key}=${value}`
        }
      } else {
        return undefined
      }
    })
    .filter(item => item)
    .join('&')

  result = queryString ? `?${queryString}` : ''

  return result
}
