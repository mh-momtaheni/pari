import ProductDetail from '@/views/ProductDetail/ProductDetail'

export default function Page() {
  return <ProductDetail />
}
