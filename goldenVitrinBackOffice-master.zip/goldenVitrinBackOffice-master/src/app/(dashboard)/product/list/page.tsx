import Product from '@/views/product'

export default function Page() {
  return <Product />
}
