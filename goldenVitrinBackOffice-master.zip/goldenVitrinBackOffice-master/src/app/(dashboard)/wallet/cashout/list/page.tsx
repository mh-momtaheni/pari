import WalletManagement from '@/views/wallet/CashoutList'

export default function Page() {
  return <WalletManagement />
}
