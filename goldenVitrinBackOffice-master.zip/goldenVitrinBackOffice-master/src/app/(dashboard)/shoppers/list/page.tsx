import React from 'react'

import ShoppersList from '@/views/shopper/Shopper'

function Shopper() {
  return <ShoppersList />
}

export default Shopper
