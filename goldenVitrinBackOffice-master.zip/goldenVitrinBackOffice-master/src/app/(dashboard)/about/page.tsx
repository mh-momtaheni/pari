export default function Page() {
  return <h1>صفحه درباره ما</h1>
}
