export default function Page() {
  return <h1>صفحه خانه</h1>
}
