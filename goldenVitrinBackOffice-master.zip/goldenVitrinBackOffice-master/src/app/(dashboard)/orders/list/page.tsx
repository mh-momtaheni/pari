import OrdersList from '@/views/orders/OrdersList'

export default function Page() {
  return <OrdersList />
}
