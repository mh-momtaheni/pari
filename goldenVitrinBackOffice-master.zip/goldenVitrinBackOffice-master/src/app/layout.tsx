// Third-party Imports
import 'react-perfect-scrollbar/dist/css/styles.css'
import { ToastContainer } from 'react-toastify'

// Type Imports
import type { ChildrenType } from '@core/types'

// Style Imports
import '@/app/globals.css'
import 'react-toastify/dist/ReactToastify.css'

// Generated Icon CSS Imports
import '@assets/iconify-icons/generated-icons.css'

import Providers from '@/utils/providers'

export const metadata = {
  title: 'پنل مدیریت ویترو',
  description: 'پنل مدیریت اپلیکیشن ویترو'
}

const RootLayout = ({ children }: ChildrenType) => {
  // Vars
  const direction = 'rtl'

  return (
    <html id='__next' lang='en' dir={direction}>
      <body className='flex is-full min-bs-full flex-auto flex-col'>
        <Providers>{children}</Providers>
        <ToastContainer
          position='bottom-left'
          autoClose={5000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme='colored'
        />
      </body>
    </html>
  )
}

export default RootLayout
