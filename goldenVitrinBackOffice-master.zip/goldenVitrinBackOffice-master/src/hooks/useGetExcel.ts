import { useMutation } from '@tanstack/react-query'

import Client from '@/utils/client'

export interface ParamsType {
  startDate: string
  endDate: string
  pageIndex: number
  pageSize: number
  sortDirection: string
  isExcelled: boolean
}

export interface params<T extends object | undefined> {
  params: T
  url: string
}

type ExcelListType = <T extends object | undefined>({ params, url }: params<T>) => Promise<BlobPart>

const getExcelList: ExcelListType = async ({ params, url }) => {
  const client = new Client()

  return await client.post(url, params, {
    'content-type': 'multipart/form-data'
  })
}

export function useGetExcel<T extends object | undefined>({ params, url }: params<T>) {
  return useMutation({
    mutationFn: () => getExcelList({ params, url }),
    mutationKey: ['excelList-query', params],
    retry: 1,
    onSuccess: data => {
      const url = window.URL.createObjectURL(new Blob([data]))
      const link = document.createElement('a')

      link.href = url
      link.setAttribute('download', 'Reports.xlsx')
      document.body.appendChild(link)
      link.click()
      link.parentNode?.removeChild(link)
    },
    onError: error => {
      console.error('Error downloading file:', error)
    }
  })
}
