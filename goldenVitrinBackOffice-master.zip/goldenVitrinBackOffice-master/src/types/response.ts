export interface ResponseItemsType<T> {
  data: {
    items: T[]
  }
}
export interface ResponseItemsWithCountType<T> {
  totalCount: number
  data: {
    items: T[]
  }
}
export interface ResponseItemType<T> {
  data: T
}
