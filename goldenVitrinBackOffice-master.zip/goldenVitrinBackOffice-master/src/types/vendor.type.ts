export type SortDirectionType = 'Descending' | 'Ascending'
export type SortConditionType = 'CreatedDate' | 'ModifiedDate'
export type VendorStatusType = 'All' | 'Pending' | 'Active' | 'Inactive' | 'Rejected' | 'Approved'

export interface VendorsListItem {
  id: number
  approveTime: string
  createdDateTime: string
  modifiedDateTime: string | null
  vendorName: string
  vendorSlug: string
  vendorStatus: string
}

export interface AllVendorsQueryParams {
  searchByVendorName?: string
  searchByVendorSlug?: string
  sortDirection?: SortDirectionType
  sortCondition?: SortConditionType
  vendorStatus?: VendorStatusType
  pageIndex?: number
  pageSize?: number
}

export interface VendorLogoType {
  id: number
  url: string
}

export interface VendorAddress {
  provinceId: number | null
  provinceName: string | null
  cityId: number | null
  cityName: string | null
  address: string | null
  postalCode: string | null
}
export interface VendorDetailItem {
  id: number
  firstName: string | null
  lastName: string | null
  nationalCode: string | null
  userId: number
  phoneNumber: string
  mobileNumber: string
  createdDateTime: string | null
  modifiedDateTime: string | null
  approveTime: string | null
  vendorName: string
  vendorStatus: VendorStatusType
  slug: string
  shortDescription: string | null
  fullDescription: string | null
  businessType: string
  aboutMe: string
  logo: {
    vendorLogo: VendorLogoType
  }
  vendorAddress: VendorAddress | null
  packagePurchase: {
    packageName: string | null
  }
  condition: {
    anyProductAdded: boolean
    anyProductApproved: boolean
    vendorOwnerAdditionalInformationCompleted: boolean
    vendorShippingFeeSubmitted: boolean
    anyActivePurchasedPackage: boolean
  }
}

export interface RejectVendorParams {
  id: string
  reasonForRejection: string
}
