export type OrderStatusType = 'WaitForPayment' | 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Rejected'
