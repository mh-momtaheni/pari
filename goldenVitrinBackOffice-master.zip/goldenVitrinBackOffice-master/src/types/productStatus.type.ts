export type ProdcutStatusType = 'Created' | 'Pending' | 'Approved' | 'NotApproved'
