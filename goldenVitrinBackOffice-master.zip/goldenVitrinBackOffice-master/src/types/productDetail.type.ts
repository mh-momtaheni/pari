export interface Image {
  id: number
  url: string
  accessibilityCaption: string | null
}

export interface ProductVariant {
  id: number
  productVariantName: string
  sku: string | null
  productVariantPrice: number
  isAvailable: boolean
  isPublished: boolean
  variantTitle: string[]
  variantId: number[]
}

interface VariantDetail {
  id: number
  title: string
  titleFa: string
  valueFa: string
  value: string
}

interface Variation {
  productVariants: ProductVariant[]
  variants: VariantDetail[]
}

export interface ProductMedia {
  thumbnailImageProduct: Image
  productImagesProduct: Image[]
  vendorLogo: Image
}

export interface ProductDetailItem {
  id: number
  name: string
  specifications: any | null // Adjust the type based on actual structure if known
  description: string
  slug: string
  metaDescription: string | null
  metaTitle: string | null
  price: number
  published: boolean
  vendorId: number
  categoryId: number
  productStatus: string
  adminComment: string | null
  shippingTime: string | null
  discount: number
  availability: string
  vendorUserId: number
  vendorName: string
  vendorSlug: string
  vendorDescription: string | null
  categoryName: string
  parentCategoryId: number | null
  productMedia: ProductMedia
  variation: Variation
  createdDateTime: string
  modifiedDateTime: string | null
  approvedDateTime: string | null
}
