import type { ReactNode } from 'react'

export interface FilterPropType {
  children: ReactNode
  className?: string
}

export interface TextFieldPropType {
  searchTerm: string
  setSearchTerm: (value: string) => void
  placeholder?: string
  className?: string
  label?: string
}

export interface SelectPropsType<T> {
  onChange: (value: T) => void
  defaultValue?: string
  items: Record<string, string | number>[]
  label?: string
  className?: string
}
export interface DatePickerPropsType {
  label: string
  date: string
  setDate: (value: string) => void
}
