export type ProdcutFilterStatusType = 'All' | 'Created' | 'Pending' | 'Approved' | 'NotApproved'

export type ProductSortConditionType = 'ModifiedDate' | 'CreatedDate' | 'Price'

export type ProductSortDirectionType = 'Ascending' | 'Descending'
