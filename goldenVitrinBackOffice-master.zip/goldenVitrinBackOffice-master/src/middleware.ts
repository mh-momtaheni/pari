import type { NextRequest } from 'next/server'
import { NextResponse } from 'next/server'

import { getToken } from 'next-auth/jwt'

export { default } from 'next-auth/middleware'

export const config = {
  // matcher solution for public, api, assets and _next exclusion
  matcher: '/((?!api|static|.*\\..*|_next).*)'
}

const unAuthenticatedUrls = ['/login']

export async function middleware(request: NextRequest) {
  const token = await getToken({ req: request })

  const isUnAuthenticatedUrls = unAuthenticatedUrls.includes(request.nextUrl.pathname)

  if (isUnAuthenticatedUrls && !token) {
    return
  }

  if (!isUnAuthenticatedUrls && !token && process.env.NEXTAUTH_URL) {
    return NextResponse.redirect(process.env.NEXTAUTH_URL + '/login')
  }
}
