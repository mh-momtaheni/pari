interface walletStatusConstantType {
  status: { [key in string | number | symbol]: string }
}

export const walletStatusConstant: walletStatusConstantType['status'] = {
  Withdrawn: 'برداشت شده',
  Requested: 'ثبت شده'
}

export const walletStatusChipsColorConstant: walletStatusConstantType['status'] = {
  Withdrawn: 'success',
  Requested: 'secondary'
}
