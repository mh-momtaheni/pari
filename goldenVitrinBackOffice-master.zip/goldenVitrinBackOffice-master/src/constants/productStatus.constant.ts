import type { ProdcutStatusType } from '@/types/productStatus.type'

interface ProductStausConstantType {
  status: { [key in ProdcutStatusType]: string }
}

// a constant for prodcut status

export const productStatusConstant: ProductStausConstantType['status'] = {
  Approved: 'تایید',
  Created: 'ساخته شده',
  Pending: 'در انتظار تایید',
  NotApproved: 'رد'
}

// a constant for the colors of the chips based on the product status

export const productStatusChipsColorConstant: ProductStausConstantType['status'] = {
  Approved: 'success',
  Created: 'secondary',
  Pending: 'warning',
  NotApproved: 'error'
}
