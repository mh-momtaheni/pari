import { type VendorStatusType } from '@/types/vendor.type'

interface VendorStausConstantType {
  status: { [key in VendorStatusType]: string }
}

// a constant for prodcut status

export const vendorStatusConstant: VendorStausConstantType['status'] = {
  All: 'همه',
  Pending: 'در انتظار',
  Active: 'فعال',
  Inactive: 'غیرفعال',
  Rejected: 'رد شده',
  Approved: 'تایید'
}

// a constant for the colors of the chips based on the product status

export const vendorStatusChipsColorConstant: VendorStausConstantType['status'] = {
  All: 'default',
  Pending: 'warning',
  Active: 'success',
  Inactive: 'primary',
  Rejected: 'error',
  Approved: 'info'
}
