import type { OrderStatusType } from '@/types/orderStatus.type'

interface OrderStausConstantType {
  status: { [key in OrderStatusType]: string }
}

// a constant for prodcut status

export const orderStatusConstant: OrderStausConstantType['status'] = {
  WaitForPayment: 'پرداخت نشده',
  Pending: ' در انتظار تایید',
  Processing: 'آماده سازی',
  Delivered: 'تحویل',
  Rejected: 'رد',
  Shipped: 'ارسال شده'
}

// a constant for the colors of the chips based on the product status

export const orderStatusChipsColorConstant: OrderStausConstantType['status'] = {
  Shipped: 'success',
  WaitForPayment: 'secondary',
  Pending: 'warning',
  Rejected: 'error',
  Delivered: 'success',
  Processing: 'primary'
}
