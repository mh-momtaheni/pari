import { useMutation } from '@tanstack/react-query'

import Client from '@/utils/client'
import { type ResponseItemType } from '@/types/response'

export interface RegisterMutationParams {
  username: string
}

export interface RegisterResponse {
  phoneNumber: string
  token: string
}

export type RegisterType = (params: RegisterMutationParams) => Promise<ResponseItemType<RegisterResponse>>

const register: RegisterType = async params => {
  const client = new Client()

  return await client.post('/v1/Identity/Register/Customer', params)
}

export function useRegister() {
  return useMutation({
    mutationFn: async (params: RegisterMutationParams) => await register(params)
  })
}
