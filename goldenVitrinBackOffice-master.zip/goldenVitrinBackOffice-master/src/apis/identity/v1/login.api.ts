import Client from '@/utils/client'
import { type ResponseItemType } from '@/types/response'

export interface LoginMutationParams {
  userName: string
  password: string
}

export interface LoginResponse {
  token: {
    token: string
    refreshToken: string
    tokenType: string
    expiresIn: string
  }
}

export type LoginType = (params: LoginMutationParams) => Promise<ResponseItemType<LoginResponse>>

export const login: LoginType = async params => {
  const baseURL = process.env.NODE_ENV === 'production' ? process.env.API_BASE_URL_SSR : process.env.API_BASE_URL
  const client = new Client(baseURL)

  return await client.post('/Dash/v1/AdminPanelIdentity/Login', params)
}
