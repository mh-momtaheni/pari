import { useMutation } from '@tanstack/react-query'

import Client from '@/utils/client'
import type { ResponseItemType } from '@/types/response'

export interface ParamsType {
  startDate: string
  endDate: string
  firstName?: string
  pageIndex: number
  pageSize: number
  sortDirection: 'Descending' | 'Ascending'
  cashoutType: 'Requested' | 'Approved' | 'Withdrawn'
}
export type DataObject<T> = {
  count: number
  cashoutListResList: T
}
export type DataType = {
  name: string
  nationalCode: string
  amount: number
  roles: string[]
  createDateTime: string // or Date if you plan to parse it into a Date object
  phoneNumber: string
  iban: string
  cashoutId: number
  cashOutStatus: 'Requested' | 'Approved' | 'Rejected' | 'Withdrawn' // Assuming these are possible statuses
}

type CashoutType = (params: ParamsType) => Promise<ResponseItemType<DataObject<DataType[]>>>

const getCashout: CashoutType = async params => {
  const client = new Client()

  return await client.post('/Dash/v1/Wallet/CashOutList', params)
}

export function useGetCashoutList(params: ParamsType) {
  return useMutation({
    mutationFn: () => getCashout(params),
    mutationKey: ['cashout-query', params],
    retry: 1,
  })
}
