import { useQuery } from '@tanstack/react-query'

import Client from '@/utils/client'
import type { ResponseItemType } from '@/types/response'
import type { OrderStatusType } from '@/types/orderStatus.type'

export type OrderStatusFilterType = 'WaitForPayment' | 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Rejected'

export type OrderSortDirectionType = 'Ascending' | 'Descending'

export interface OrdersListParams {
  orderStatus?: OrderStatusType
  sortDirection?: OrderSortDirectionType
  pageIndex: number
  pageSize: number
  vendorSlug?: string
}

export interface OrderItem {
  orderId: number
  vendorName: string
  finalPrice: number
  dateTime: string
  orderStatus: OrderStatusType
}

export type DataObject = {
  orderCount: number
  orderList: OrderItem[]
}

type OrdersListType = (params: OrdersListParams) => Promise<ResponseItemType<DataObject>>

const getOrdersList: OrdersListType = async (params: OrdersListParams) => {
  const client = new Client()

  return await client.get('/Dash/v2/Order/OrdersList', params)
}

export default function useGetOrdersList(params: OrdersListParams) {
  return useQuery({
    queryFn: async () => await getOrdersList(params),
    queryKey: ['Orders-list', params],
    retry: 1,
    select: data => data?.data
  })
}
