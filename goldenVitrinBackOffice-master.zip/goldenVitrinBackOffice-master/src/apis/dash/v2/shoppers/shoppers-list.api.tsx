import type { UseQueryResult } from '@tanstack/react-query'
import { useQuery } from '@tanstack/react-query'

import Client from '@/utils/client'
import type { ResponseItemsWithCountType } from '@/types/response'

export interface ShopperListParams {
  SortDirection: string
  SortCondition?: string
  PhoneNumber?: string
  PageIndex: number
  PageSize: number
}
export interface ResponseData {
  id: number
  firstName: string
  lastName: string
  phoneNumber: string
  createdDateTime: string
  modifiedDateTime?: string
}
type GetShopperListType = (params: ShopperListParams) => UseQueryResult<ResponseItemsWithCountType<ResponseData>, Error>

const getShpppers = async (params: ShopperListParams) => {
  const client = new Client()

  return await client.get('/Dash/v2/Shopper/GetShopperList', params)
}

export const useGetShoppersList: GetShopperListType = params => {
  return useQuery({
    queryFn: () => getShpppers(params),
    queryKey: ['shoppers-list', params]
  })
}
