import { useQuery } from '@tanstack/react-query'

import type { ProductDetailItem } from '@/types/productDetail.type'
import type { ResponseItemType } from '@/types/response'
import Client from '@/utils/client'

export interface ProductDetailParams {
  id: number
}

type ProductDetailType = (params: ProductDetailParams) => Promise<ResponseItemType<ProductDetailItem>>

const getProductDetailItem: ProductDetailType = async ({ id }: ProductDetailParams) => {
  const client = new Client()

  return await client.get(`/Dash/v2/Product/ProductDetail/${id}`)
}

export default function useGetProductDetailItem({ id }: ProductDetailParams) {
  return useQuery({
    queryFn: async () => await getProductDetailItem({ id }),
    queryKey: ['Product-deatil', id],
    retry: 1,
    select: data => data?.data
  })
}
