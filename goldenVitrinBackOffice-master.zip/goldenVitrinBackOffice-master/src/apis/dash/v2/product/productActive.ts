import { useMutation, useQueryClient } from '@tanstack/react-query'

import Client from '@/utils/client'

interface ProductActiveParams {
  id: number
}

export type ProductActive = (params: ProductActiveParams) => Promise<[]>

const activeProduct: ProductActive = async (params: ProductActiveParams) => {
  const client = new Client()

  return await client.post(`/Dash/v2/Product/ActiveProduct/${params.id}`)
}

export const useActiveProduct = (params: ProductActiveParams) => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async () => await activeProduct(params),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['Product-deatil', params.id] })
    }
  })
}
