import { useMutation, useQueryClient } from '@tanstack/react-query'

import Client from '@/utils/client'

interface ProductDeactiveParams {
  id: number
}

interface ProductDeactivePayload {
  comment: string
}

type ProductDeactiveResponse = '' | []

export type ProductDeactive = (
  params: ProductDeactiveParams,
  payload: ProductDeactivePayload
) => Promise<ProductDeactiveResponse>

const deactiveProduct: ProductDeactive = async (params: ProductDeactiveParams, payload: ProductDeactivePayload) => {
  const client = new Client()

  return await client.post(`/Dash/v2/Product/DeActiveProduct/${params.id}`, payload)
}

export const useDeactiveProduct = (params: ProductDeactiveParams) => {
  const queryClient = useQueryClient()

  return useMutation<ProductDeactiveResponse, ProductDeactiveParams, ProductDeactivePayload>({
    mutationFn: async payload => await deactiveProduct(params, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['Product-detail', params.id] })
    }
  })
}
