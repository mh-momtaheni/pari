import { useQuery } from '@tanstack/react-query'

import type { ResponseItemType } from '@/types/response'
import Client from '@/utils/client'
import type { ProdcutStatusType } from '@/types/productStatus.type'

export interface ProductListParams {
  sortDirection: 'Ascending' | 'Descending'
  productStatus: 'All' | 'Created' | 'Pending' | 'Approved' | 'NotApproved'
  categoryId?: number
  slug?: string
  vendorId?: number
  productName?: string
  productId?: number
  sortCondition?: 'ModifiedDate' | 'CreatedDate' | 'Price'
  pageIndex: number
  pageSize: number
}

export interface ProductItem {
  name: string
  productStatus: ProdcutStatusType
  createdDateTime: string
  modifiedDateTime: string
  approvedDateTime: string
  thumbnailImage: string
  adminComment: string
  vendorName: string
  slug: string
  id: number
}

export type DataObject = {
  productCount: number
  vendorProducts: ProductItem[]
}

type ProductListType = (params: ProductListParams) => Promise<ResponseItemType<DataObject>>

const getProductList: ProductListType = async (params: ProductListParams) => {
  const client = new Client()

  return await client.get('/Dash/v2/Product/GetProductList', params)
}

export default function useGetProductList(params: ProductListParams) {
  return useQuery({
    queryFn: async () => await getProductList(params),
    queryKey: ['Product-list', params],
    retry: 1,
    select: data => data?.data
  })
}
