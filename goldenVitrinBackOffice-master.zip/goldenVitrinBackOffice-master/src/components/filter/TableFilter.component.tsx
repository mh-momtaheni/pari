import React, { useState } from 'react'

import { CardContent, MenuItem } from '@mui/material'

import classNames from 'classnames'

import { TextFieldInput } from '@/components/text-field/text-field.component'
import MainDatePicker from '@/components/datePicker'
import type { DatePickerPropsType, FilterPropType, SelectPropsType, TextFieldPropType } from '@/types/filter.type'
import SelectInput from '@/components/select/select.component'

export default function Filter({ children, className }: FilterPropType) {
  return (
    <CardContent className='flex justify-between w-full flex-col items-start md:items-center md:flex-row gap-4'>
      <div className={classNames('flex items-center justify-between gap-4', className)}>{children}</div>
    </CardContent>
  )
}

const Select = <T,>({ onChange, label = '', items, defaultValue, className }: SelectPropsType<T>) => {
  const [value, setValue] = useState<string>(defaultValue ?? '')

  const onChangeHandler = (val: T) => {
    setValue(val as string)

    if (onChange) {
      onChange(val)
    }
  }

  return (
    <SelectInput
      value={value}
      onChange={(e: { target: { value: T } }) => onChangeHandler(e.target.value as T)}
      className={classNames('!is-[160px]', className)}
      label={label}
      selection={items.map(item => (
        <MenuItem key={item.value} value={item.value}>
          {item.name}
        </MenuItem>
      ))}
    />
  )
}

function TextField({ searchTerm, setSearchTerm, label = '', placeholder = 'جستجو...', className }: TextFieldPropType) {
  return (
    <>
      <TextFieldInput
        value={searchTerm ?? ''}
        onChange={(value: string | number) => setSearchTerm(String(value))}
        placeholder={placeholder}
        label={label}
        className={classNames('is-[160px]', className)}
      />
    </>
  )
}

function DatePicker({ label, date, setDate }: DatePickerPropsType) {
  return <MainDatePicker label={label} date={date} setDate={value => setDate(value)} />
}

Filter.Select = Select
Filter.TextField = TextField
Filter.DatePicker = DatePicker

