//  import type { FocusEvent } from 'react'

// ** Third Party Imports
import type { DateObject } from 'react-multi-date-picker'
import ReactDatePicker from 'react-multi-date-picker'
import persian_calendar from 'react-date-object/calendars/persian'
import persian_locale from 'react-date-object/locales/persian_fa'

import { CacheProvider } from '@emotion/react'

import createCache from '@emotion/cache'

import rtlPlugin from 'stylis-plugin-rtl'

import styles from './DatePicker.module.css'
import Input from './PickerInput'

type Props = {
  date: string
  setDate: (value: string) => void
  label: string
  disablePastDays?: boolean
  disableFutureDate?: boolean
}

export default function DatePicker({ setDate, date, label, disablePastDays, disableFutureDate }: Props) {
  const onChangeHandler = (value: DateObject | DateObject[] | null): void => {
    const newValue: any = value?.valueOf()
    const date = new Date(newValue)
    const stringDate = date.toISOString()

    setDate(stringDate)
  }

  const tomorrow = new Date()

  tomorrow.setDate(tomorrow.getDate() + 1)

  const cacheRtl = createCache({
    key: 'muirtl',
    stylisPlugins: [rtlPlugin]
  })

  return (
    <CacheProvider value={cacheRtl}>
      <ReactDatePicker
        style={{ width: '100%' }}
        locale={persian_locale}
        calendar={persian_calendar}
        onChange={value => {
          onChangeHandler(value)
        }}
        value={new Date(date)}
        render={<Input label={label} />}
        minDate={disablePastDays ? tomorrow : undefined}
        maxDate={disableFutureDate ? tomorrow : undefined}
        format='dddd D MMMM YYYY'
        containerClassName={styles.datePicker}
        inputMode='none'
      />
    </CacheProvider>
  )
}
