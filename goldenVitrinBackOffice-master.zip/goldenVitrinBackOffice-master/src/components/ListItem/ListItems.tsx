import React, { type ReactNode, type ReactElement } from 'react'

import { Typography } from '@mui/material'

interface Item {
  label: string
  info: string | number | ReactNode
}

interface Props {
  items: Item[]
}

export default function ListItems({ items }: Props): ReactElement {
  return (
    <>
      {items.map(item => (
        <div key={item.label} className='flex   justify-between pb-2 '>
          <Typography className='text-sm  font-light'>{item.label}</Typography>

          <div className='text-[16px] '>{item.info}</div>
        </div>
      ))}
    </>
  )
}
