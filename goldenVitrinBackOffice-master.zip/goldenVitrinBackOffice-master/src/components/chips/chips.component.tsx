import Chip from '@mui/material/Chip'

export type ChipsColorTypes = 'primary' | 'secondary' | 'error' | 'success' | 'warning' | 'info'

interface Props {
  label: string
  color: ChipsColorTypes
  className?: string
}

const StatusChips = ({ label, color = 'primary', className }: Props) => {
  return <Chip label={label} color={color} className={className} />
}

export default StatusChips
