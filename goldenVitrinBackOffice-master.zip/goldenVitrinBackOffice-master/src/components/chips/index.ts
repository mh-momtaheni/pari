export { default } from './chips.component'
