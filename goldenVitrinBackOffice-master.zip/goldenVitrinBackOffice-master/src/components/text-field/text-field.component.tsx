import * as React from 'react'

import { useEffect, useState } from 'react'

import type { TextFieldProps } from '@mui/material/TextField'
import TextField from '@mui/material/TextField'
import rtlPlugin from 'stylis-plugin-rtl'

import { CacheProvider } from '@emotion/react'
import createCache from '@emotion/cache'

export const TextFieldInput = ({
  value: initialValue,
  onChange,
  debounce = 500,
  label = '',
  ...props
}: {
  value: string | number
  onChange: (value: string | number) => void
  debounce?: number
} & Omit<TextFieldProps, 'onChange'>) => {
  // States
  const [value, setValue] = useState(initialValue)

  useEffect(() => {
    setValue(initialValue)
  }, [initialValue])

  useEffect(() => {
    const timeout = setTimeout(() => {
      onChange(value)
    }, debounce)

    return () => clearTimeout(timeout)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value])

  const cacheRtl = createCache({
    key: 'muirtl',
    stylisPlugins: [rtlPlugin]
  })

  return (
    <CacheProvider value={cacheRtl}>
      <TextField
        {...props}
        label={label !== '' ? label : 'جستجو...'}
        inputProps={{ style: { height: '16px', paddingTop: '10px', paddingBottom: '12px' } }}
        onChange={e => setValue(e.target.value)}
        placeholder='جستجو...'
        InputLabelProps={{ style: { top: '-5px', fontSize: '13px' } }}
      />
    </CacheProvider>
  )
}
