'use client'

// Next Imports
import Link from 'next/link'

// Third-party Imports
import classnames from 'classnames'

// Util Imports
import { verticalLayoutClasses } from '@layouts/utils/layoutClasses'

const FooterContent = () => {
  return (
    <div
      className={classnames(verticalLayoutClasses.footerContent, 'flex items-center justify-between flex-wrap gap-4')}
    >
      <p>
        <span className='text-textSecondary'>{` توسعه داده شده با `}</span>
        <span>{`❤️`}</span>
        <span className='text-textSecondary'>{` توسط تیم `}</span>
        <Link href='https://naqshavatech.com' target='_blank' className='text-primary uppercase'>
          نقش آوا تک
        </Link>
        {` © ${new Date().getFullYear()} `}
      </p>
    </div>
  )
}

export default FooterContent
