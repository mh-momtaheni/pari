import React from 'react'

import rtlPlugin from 'stylis-plugin-rtl'

import { CacheProvider } from '@emotion/react'
import createCache from '@emotion/cache'
import { FormControl, InputLabel, Select } from '@mui/material'
import classNames from 'classnames'

function SelectInput({ props, className, value, onChange, label = '', selection }: any) {
  const cacheRtl = createCache({
    key: 'muirtl',
    stylisPlugins: [rtlPlugin]
  })

  return (
    <CacheProvider value={cacheRtl}>
      <FormControl sx={{ m: 1, minWidth: 120 }} size='small'>
        <InputLabel id='select-label' className='text-sm'>
          {label}
        </InputLabel>
        <Select
          {...props}
          labelId='select-label'
          value={value}
          label={label}
          onChange={onChange}
          className={classNames(className)}
        >
          {selection}
        </Select>
      </FormControl>
    </CacheProvider>
  )
}

export default SelectInput
