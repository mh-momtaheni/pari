export { default } from './pagination-component'
