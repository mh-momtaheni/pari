export { default } from './components/main.component'
