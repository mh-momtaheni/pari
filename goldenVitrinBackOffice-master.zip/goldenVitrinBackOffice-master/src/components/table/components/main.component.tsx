import type { ChangeEvent } from 'react'
import React from 'react'

import { Button, Pagination } from '@mui/material'

import type { Table as TableType } from '@tanstack/react-table'

import classNames from 'classnames'

import TableHeader from './table.header.component'
import TableBody from './table.body.component'

interface PaginationProps {
  page: number
  pageCount: number
  onPagination: (event: ChangeEvent<unknown>, value: number) => void
}
interface Props {
  table: TableType<any>
  styles: any
  pagination?: PaginationProps
  isLoading?: boolean
  excelFunction?: VoidFunction
  className?: string
}

function TableComponent({
  table,
  styles,
  pagination = { onPagination: () => {}, page: 0, pageCount: 0 },
  isLoading,
  excelFunction,
  className
}: Props) {
  return (
    <div className='flex h-full w-full flex-col'>
      {!isLoading ? (
        <>
          <div className='ml-6 mb-6' style={{ direction: 'ltr' }}>
            {excelFunction && (
              <Button variant='contained' size='medium' onClick={excelFunction}>
                خروجی اکسل
              </Button>
            )}
          </div>
          <table className={classNames(styles.table, className)}>
            <TableHeader table={table} {...(excelFunction && { excelFunction })} />
            <TableBody table={table} />
          </table>
        </>
      ) : (
        <div className='w-full h-full flex justify-center items-center  pb-6   '>
          <h1 className='font-bold'>در حال بارگذاری...</h1>
        </div>
      )}

      {pagination && (
        <Pagination
          count={Math.ceil(pagination.pageCount / 20)}
          page={pagination.page}
          onChange={pagination.onPagination}
          variant='tonal'
          color='primary'
          style={{ direction: 'ltr' }}
          className='mt-6 pb-6'
        />
      )}
    </div>
  )
}

export default TableComponent
