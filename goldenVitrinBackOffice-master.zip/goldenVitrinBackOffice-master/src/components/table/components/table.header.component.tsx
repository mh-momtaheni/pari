import React from 'react'

import type { Table } from '@tanstack/react-table'
import { flexRender } from '@tanstack/react-table'

export interface TableHeaderProps {
  table: Table<any>
}

function TableHeader({ table }: TableHeaderProps) {
  return (
    <thead>
      {table.getHeaderGroups().map(headerGroup => (
        <tr key={headerGroup.id}>
          {headerGroup.headers.map(header => (
            <th key={header.id}>
              {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
            </th>
          ))}
        </tr>
      ))}
    </thead>
  )
}

export default TableHeader
