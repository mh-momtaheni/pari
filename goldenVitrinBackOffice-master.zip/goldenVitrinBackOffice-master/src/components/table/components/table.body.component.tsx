import React from 'react'

import { flexRender, type Table } from '@tanstack/react-table'

function TableBody({ table }: { table: Table<any> }) {
  return (
    <tbody>
      {table
        .getRowModel()
        .rows.slice(0, 20)
        .map(row => (
          <tr key={row.id}>
            {row.getVisibleCells().map(cell => (
              <td key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</td>
            ))}
          </tr>
        ))}
    </tbody>
  )
}

export default TableBody
