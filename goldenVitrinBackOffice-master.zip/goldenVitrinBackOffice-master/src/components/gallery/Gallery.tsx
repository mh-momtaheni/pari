import React, { type ReactElement } from 'react'

import Image from 'next/image'

import { Grid } from '@mui/material'

import type { Image as ImageType } from '@/types/productDetail.type'

interface Props {
  images: ImageType[]
  imageWidth: number
  imageHeight: number
}

export default function Gallery({ images, imageHeight = 300, imageWidth = 300 }: Props): ReactElement {
  return (
    <Grid container direction='row' justifyContent='start' alignItems='center' columnGap={32} rowGap={12}>
      {images?.map(image => (
        <Image
          width={imageWidth}
          height={imageHeight}
          src={image?.url}
          alt={String(image?.id)}
          key={image?.id}
          className='rounded-md'
          objectFit='fill'
        />
      ))}
    </Grid>
  )
}
