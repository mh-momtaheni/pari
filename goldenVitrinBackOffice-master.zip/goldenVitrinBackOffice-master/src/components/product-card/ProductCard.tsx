import React, { type ReactNode, type ReactElement } from 'react'

import { Card, CardContent, Typography } from '@mui/material'
import classNames from 'classnames'

interface Props {
  title: string
  children: ReactNode
  buttons?: ReactNode
  className?: string
}

export default function ProductCard({ children, title, buttons, className }: Props): ReactElement {
  return (
    <Card className={classNames('flex w-full flex-col pt-5 px-3  shadow-none', className)}>
      <div className='w-full flex justify-between items-center'>
        <Typography className='text-xl font-bold pr-6'>{title}</Typography>
        {buttons}
      </div>

      <span className='   border-b-[2px] mt-3' />

      <CardContent>{children}</CardContent>
    </Card>
  )
}
