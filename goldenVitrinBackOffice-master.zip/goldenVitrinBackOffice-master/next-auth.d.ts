import NextAuth from 'next-auth/next'
declare module 'next-auth' {
  interface Session {
    user: {
      refreshToken: string
      tokenType: string
      token: string
      expiresIn: number
      user: number
      userName: string
    }
  }
}
